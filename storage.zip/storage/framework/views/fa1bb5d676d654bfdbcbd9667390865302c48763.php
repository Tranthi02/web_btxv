
<?php $__env->startSection('content'); ?>
<div class="slideshow">
    <div class="box-slide">
        <div class="slider-wrapper theme-default">
            <div class="slider-main" class="nivoSlider">
            </div>
        </div>
    </div>
</div>
<div class="swap-content w-clear" style="margin-top: 30px">

    <div id="box-product-home" class="spnoibat">
        <div class="container">
            <div class="title">
                <h2>Sản Phẩm Nổi Bật</h2>
            </div>
            
            <div class="w-clear center news_chil" style="padding-top: 40px;">
            <?php $__currentLoopData = $sanphamnoibat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spnb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="item item-home">
                    <div class="images">
                        <a href="/chi-tiet-san-pham/<?php echo e($spnb->slug); ?>" title="<?php echo e($spnb->title); ?> ">
                            <img src="/storage/<?php echo e($spnb->thumbnail); ?>" alt="<?php echo e($spnb->title); ?> " class="img-responsive" style="width: 350px; height: 308px"/>
                        </a>
                    </div>
                    <div class="product-name text-uppercase">
                        <a href="/chi-tiet-san-pham/<?php echo e($spnb->slug); ?>" title="<?php echo e($spnb->title); ?> "><?php echo e($spnb->title); ?> </a>
                        <div class="giakm">
                        <?php echo e($spnb->price); ?> <span>VNĐ</span>
                        </div>
                    </div>
                    <div class="product-detail text-center">
                        <a href="/chi-tiet-san-pham/<?php echo e($spnb->slug); ?>" title="<?php echo e($spnb->slug); ?> ">
                            <img src="../images/icon-book.png" alt="Chi Tiết"> Chi Tiết
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="products Load__ajax__tabs"></div>
        </div>
    </div>
    <div id="box-news">
        <div class="container">
            <div class="title">
                <h2>Tin Tức Hoạt Động</h2>
            </div>
            <div class="news-content">
                <?php $__currentLoopData = $tintuchoatdong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tthd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="item-news">
                        <a href="chi-tiet-tin-tuc/<?php echo e($tthd->slug); ?>" title="<?php echo e($tthd->title); ?>">
                            <div class="image">
                                <img src="/storage/<?php echo e($tthd->thumbnail); ?>"  style="width: 273px; height: 218px" alt="<?php echo e($tthd->title); ?>" class="img-responsive" />
                                <div class="date"><?php echo e($tthd->created_at); ?></div>
                            </div>
                            <div class="title"><?php echo e($tthd->title); ?></div>
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>


    <div id="box-video">
        <div class="container">
            <div class="title">
                <h2>Video</h2>
            </div>
            <div class="video-content row">
                <?php $__currentLoopData = $videomsx; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vdmsx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item-video col-sm-6 col-md-4">
                    <a href="/chi-tiet-video/<?php echo e($vdmsx->slug); ?>">
                        <div class="image">
                            <img src="/storage/<?php echo e($vdmsx->thumbnail); ?>" alt="<?php echo e($vdmsx->name); ?>">
                        </div>
                        <div class="video-name"><?php echo e($vdmsx->name); ?></div>
                        <span class="hover-video"></span>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('thucphamquangtrang.views.layouts.trangchu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\web_ocoop\resources\views/thucphamquangtrang/posts/home.blade.php ENDPATH**/ ?>