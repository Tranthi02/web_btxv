
<?php $__env->startSection('content'); ?>

<?php if($cauchuyensanpham): ?>
<main id="main" class="">
    <div cl ass="page-wrapper page-left-sidebar" style="padding-top: 30px;
    padding-bottom: 30px;">
        <div class="row">
            <div id="content" class="large-12 right col" role="main">
                <div class="page-inner">
                    <h1 style="text-align: center">
                        <?php echo e($cauchuyensanpham->title); ?>

                    </h1>
                    <p>
                       <?php echo $cauchuyensanpham->content; ?>

                    </p>
                </div>
            </div>
        </div>
    </div>
</main>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ocbuouden.views.layouts.trangchu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\web_ocoop\resources\views/ocbuouden/posts/cauchuyensanpham.blade.php ENDPATH**/ ?>