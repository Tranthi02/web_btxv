<!doctype html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="vi"> <!--<![endif]-->

<!-- Mirrored from lonmuongxin.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 Jul 2023 07:23:54 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<head>

    <!-- Basic page needs ================================================== -->
    <meta charset="utf-8">
    <!-- Title and description ================================================== -->
    <title>
        LỢN MƯỜNG XỊN.com
    </title>
    <meta name="keywords" content="LỢN MƯỜNG XỊN.com, lonmuongxin.com" />

    <meta name="description" content="LỢN MƯỜNG XỊN.com - V&#236; sức khỏe cộng đồng ph&#225;t triển bền vững với gi&#225; trị nhượng quyền h&#224;ng đầu. Cam kết b&#225;n h&#224;ng với gi&#225; b&#236;nh ổn, hợp l&#253;, chất lượng tốt nhất.">

    <meta name="format-detection" content="telephone=no">

    <meta property="og:type" content="website">
    <meta property="og:title" content="LỢN MƯỜNG XỊN.com">
    <meta property="og:image" content="../bizweb.dktcdn.net/100/150/388/themes/517622/assets/logo88b8.png">
    <meta property="og:image:secure_url" content="../bizweb.dktcdn.net/100/150/388/themes/517622/assets/logo88b8.png">

    <meta property="og:description" content="LỢN MƯỜNG XỊN.com - V&#236; sức khỏe cộng đồng ph&#225;t triển bền vững với gi&#225; trị nhượng quyền h&#224;ng đầu. Cam kết b&#225;n h&#224;ng với gi&#225; b&#236;nh ổn, hợp l&#253;, chất lượng tốt nhất.">

    <meta property="og:url" content="index.html">
    <meta property="og:site_name" content="LỢN MƯỜNG XỊN.com">
    <!-- Product meta ================================================== -->
    <!-- 

  <meta property="og:url" content="https://lonmuongxin.com/">
  <meta property="og:site_name" content="LỢN MƯỜNG XỊN.com"> -->
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyANtAub8PiT6ZJd-0wf3MemSUHtnldUAHw&amp;callback=initMap" type="text/javascript"></script>

    <!-- Helpers ================================================== -->
    <link rel="canonical" href="index.html">
    <meta name="viewport" content="width=device-width,initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" href="../bizweb.dktcdn.net/100/150/388/themes/517622/assets/favicon88b8.png" type="image/x-icon" />
    <!-- Scripts -->

    <!-- Styles -->

    <!-- Header hook for plugins ================================================== -->
    <script>
        var Bizweb = Bizweb || {};
        Bizweb.store = 'lonmuongxin.mysapo.net';
        Bizweb.id = 150388;
        Bizweb.theme = {
            "id": 517622,
            "name": "LỢN MƯỜNG XỊN.com 2017",
            "role": "main"
        };
        Bizweb.template = 'index';
        if (!Bizweb.fbEventId) Bizweb.fbEventId = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0,
                v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    </script>
    <script>
        (function() {
            function asyncLoad() {
                var urls = ["https://maps.sapoapps.vn/CreateScriptTag/CreateScriptTag?store=lonmuongxin.mysapo.net", "../bwstatistics.sapoapps.vn/genscript/script5fa3.js?store=lonmuongxin.mysapo.net", "../bwstatistics.sapoapps.vn/genscript/script5fa3.js?store=lonmuongxin.mysapo.net", "../blogstatistics.sapoapps.vn/scripts/ab_blogstatistics_scripttag5fa3.js?store=lonmuongxin.mysapo.net", "../static.zotabox.com/0/7/07bb0328a24e481b746aa1f0d1d89c81/widgets5fa3.js?store=lonmuongxin.mysapo.net", "//static.zotabox.com/0/7/07bb0328a24e481b746aa1f0d1d89c81/widgets.js?store=lonmuongxin.mysapo.net"];
                for (var i = 0; i < urls.length; i++) {
                    var s = document.createElement('script');
                    s.type = 'text/javascript';
                    s.async = true;
                    s.src = urls[i];
                    var x = document.getElementsByTagName('script')[0];
                    x.parentNode.insertBefore(s, x);
                }
            };
            window.attachEvent ? window.attachEvent('onload', asyncLoad) : window.addEventListener('load', asyncLoad, false);
        })();
    </script>

    <script>
        window.BizwebAnalytics = window.BizwebAnalytics || {};
        window.BizwebAnalytics.meta = window.BizwebAnalytics.meta || {};
        window.BizwebAnalytics.meta.currency = 'VND';
        window.BizwebAnalytics.tracking_url = 's.html';

        var meta = {};


        for (var attr in meta) {
            window.BizwebAnalytics.meta[attr] = meta[attr];
        }
    </script>

    <script src="../js/lonrunglai/stats.min4143.js?v=69e02f0"></script>

    <script type="text/javascript">
        UA - 98923931 - 1
    </script>
    <script>
        window.enabled_enhanced_ecommerce = false;
    </script>

    <!--Facebook Pixel Code-->
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }
        (window,
            document, 'script', '../connect.facebook.net/en_US/fbevents.js');
        fbq('init', '1684007015167562', {}, {
            'agent': 'plsapo'
        }); // Insert your pixel ID here.
        fbq('track', 'PageView', {}, {
            eventID: Bizweb.fbEventId
        });
    </script>
    <noscript>
        <img height='1' width='1' style='display:none' src='https://www.facebook.com/tr?id=1684007015167562&amp;ev=PageView&amp;noscript=1' />
    </noscript>
    <!--DO NOT MODIFY-->
    <!--End Facebook Pixel Code-->

    <script>
        var eventsListenerScript = document.createElement('script');
        eventsListenerScript.async = true;

        eventsListenerScript.src = "../js/lonrunglai/store_events_listener.min983a.js?v=8ee4227";

        document.getElementsByTagName('head')[0].appendChild(eventsListenerScript);
    </script>

    <!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->
    <!--[if IE 7]>

<![endif]-->
    <!--[if lt IE 9]>
<![endif]-->
    <script type="text/javascript" src="../js/lonrunglai/jquery.min.js"></script>

    <link href="../css/lonrunglai/bootstrap.min88b8.css" rel="stylesheet" type="text/css" media="all" />
    <link href="../css/lonrunglai/blogmate88b8.css" rel="stylesheet" type="text/css" media="all" />
    <link href="../css/lonrunglai/flexslider88b8.css" rel="stylesheet" type="text/css" media="all" />
    <link href="../css/lonrunglai/filter88b8.css" rel="stylesheet" type="text/css" media="all" />
    <link href="../css/lonrunglai/owl.carousel88b8.css" rel="stylesheet" type="text/css" media="all" />

    <link href="../css/lonrunglai/animate88b8.css" rel="stylesheet" type="text/css" media="all" />

    <link href="../css/lonrunglai/jgrowl88b8.css" rel="stylesheet" type="text/css" media="all" />
    <link href="../css/lonrunglai/style.css" rel="stylesheet" type="text/css" media="all" />
    
    <script>
        var ProductReviewsAppUtil = ProductReviewsAppUtil || {};
    </script>
    <link href="../css/lonrunglai/bw-statistics-style88b8.css" rel="stylesheet" type="text/css" media="all" />
    <link href="../css/lonrunglai/appbulk-blog-statistics88b8.css" rel="stylesheet" type="text/css" media="all" />
</head>

<body id="lon-muong-xin-com" class="  cms-index-index cms-home-page">
    <h1 style="display:none">LỢN MƯỜNG XỊN.com</h1>
    <header>
        <div class="header-top hidden-xs">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-xs-7">
                        <!-- Default Welcome Message -->
                        <div class="hidden-xs" style="padding:10px 0; font-size:12px">Chào Mừng
                            tới LỢN MƯỜNG XỊN.com !</div>
                        <!-- End Default Welcome Message -->
                    </div>

                    <div class="col-sm-6 col-xs-5">
                        <div class="row">
                            <div class="toplinks toplink-lg">
                                <div class="links">

                                    

                                </div>
                                <!-- links -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-container">
            <div class="header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-2 col-sm-2">
                            <div class="logo">
                                <h1 style="margin:0">
                                    <a title="LỢN MƯỜNG XỊN.com" href="index.html">
                                        <img alt="LỢN MƯỜNG XỊN.com" src="../bizweb.dktcdn.net/100/150/388/themes/517622/assets/logo88b8.png">
                                    </a>
                                </h1>
                            </div>
                            <!-- Default Welcome Message -->

                            <!-- End Default Welcome Message -->
                        </div>

                        <div class="col-md-8 col-sm-7 hidden-xs">
                            <div class="row">

                                <div class="toplinks">
                                    <div class="links">
                                        <form action="" method="get" id="search_mini_form">
                                            <div class="input-search">
                                                <input type="text" placeholder="Nhập từ khóa tìm kiếm" value name="query">
                                                <button><img src="../images/search88b8.png" id="icon_search" title="search" alt="search" /></button>
                                            </div>
                                        </form>

                                        <div class>
                                            <span class="phonenumber">Hỗ trợ 24/7 <p><b><a href="tel:0789 330 330">0789 330 330</a></b></p></span>
                                        </div>

                                        <!-- links -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-3 cart-header hidden-xs">
                            <div class="top-cart-contain">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <nav>
        <div class="container">
            <div class="row">
                <div class="nav-inner">
                    <!-- mobile-menu -->
                    <div class="hidden-desktop" id="mobile-menu">
                        <ul class="navmenu">
                            <li>
                                <div class="menutop">
                                    <div class="toggle"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span></div>
                                    <h2>Menu</h2>
                                </div>
                                <ul style="display:none;" class="submenu">
                                    <li>
                                        <ul class="topnav">

                                            <li class="level0 level-top parent">
                                                <div><span><a href="account/login.html" id="customer_login_link">Đăng nhập</a></span></div>
                                            </li>
                                            <li class="level0 level-top parent">
                                                <div><span><a href="account/register.html" id="customer_register_link">Đăng ký</a></span></div>
                                            </li>

                                            <li class="level0 level-top parent"><a class="level-top" href="index.html"> <span>Trang chủ</span> </a>
                                                <ul class="level0">

                                                </ul>
                                            </li>

                                            <li class="level0 level-top parent"><a class="level-top" href="gioi-thieu.html"> <span>Giới thiệu</span> </a>
                                                <ul class="level0">

                                                    <li class="level1"> <a href="gioi-thieu.html"> <span>Giới thiệu</span>
                                                        </a>
                                                        <ul class="level1">

                                                            <li class="level2"><a href="gioi-thieu.html"><span>Giới thiệu</span></a></li>

                                                        </ul>
                                                    </li>

                                                </ul>
                                            </li>

                                            <li class="level0 level-top parent"><a class="level-top" href="collections/all.html"> <span>Sản phẩm</span> </a>
                                                <ul class="level0">

                                                    <li class="level1"> <a href="lon-viet-nam.html"> <span>Lợn Nguyên
                                                                Con</span> </a>

                                                    <li class="level1"> <a href="lonhuuco.html"> <span>SP Hướng Hữu
                                                                Cơ</span> </a>

                                                </ul>
                                            </li>

                                            <li class="level0 level-top parent"><a class="level-top" href="tin-tuc.html"> <span>Tin tức</span> </a>
                                                <ul class="level0">

                                                    <li class="level1"> <a href="tin-tuc.html"> <span>Tin Tức mới</span>
                                                        </a>
                                                        <ul class="level1">

                                                            <li class="level2"><a href="ban-lon-muong-chinh-cong-dac-san-lon-muong-mien-bac.html"><span>Bán
                                                                        lợn mường chính cống - Đặc sản lợn Mường miền Bắc</span></a></li>

                                                        </ul>
                                                    </li>

                                                    <li class="level1"> <a href="tin-nong-nghiep.html"> <span>Tin
                                                                Nông nghiệp</span> </a>

                                                    <li class="level1"> <a href="an-toan-ve-sinh-thuc-pham.html">
                                                            <span>An Toàn Vệ Sinh Thực Phẩm</span> </a>
                                                        <ul class="level1">

                                                            <li class="level2"><a href="ban-lon-muong-chinh-cong-dac-san-lon-muong-mien-bac.html"><span>Bán
                                                                        lợn mường chính cống - Đặc sản lợn Mường miền Bắc</span></a></li>

                                                        </ul>
                                                    </li>

                                                    <li class="level1"> <a href="nau-co.html"> <span>Món Ngon Mỗi
                                                                Ngày</span> </a>

                                                    <li class="level1"> <a href="goc-bao-chi.html"> <span>Góc Báo
                                                                Chí</span> </a>
                                                        <ul class="level1">

                                                            <li class="level2"><a href="chung-nhan-an-toan.html"><span>Chứng
                                                                        Nhận An Toàn</span></a></li>

                                                        </ul>
                                                    </li>

                                                </ul>
                                            </li>

                                            <li class="level0 level-top parent"><a class="level-top" href="index.html"> <span>Chứng nhận an toàn</span> </a>
                                                <ul class="level0">

                                                    <li class="level1"> <a href="chung-nhan-an-toan.html"> <span>Chứng
                                                                Nhận An Toàn</span> </a>
                                                        <ul class="level1">

                                                            <li class="level2"><a href="chung-nhan-an-toan.html"><span>Chứng
                                                                        Nhận An Toàn</span></a></li>

                                                            <li class="level2"><a href="gioi-thieu-ve-globalgap.html"><span>Giới
                                                                        thiệu về GlobalGAP</span></a></li>

                                                            <li class="level2"><a href="gioi-thieu-ve-vietgap.html"><span>Giới
                                                                        thiệu về VietGAP</span></a></li>

                                                            <li class="level2"><a href="gioi-thieu-ve-pgs.html"><span>Giới
                                                                        thiệu về PGS</span></a></li>

                                                            <li class="level2"><a href="gioi-thieu-ve-lifsap.html"><span>Giới
                                                                        thiệu về LifSap</span></a></li>

                                                            <li class="level2"><a href="chat-luong-quoc-te.html"><span>Chất
                                                                        lượng Quốc tế</span></a></li>

                                                        </ul>
                                                    </li>

                                                    <li class="level1"> <a href="gioi-thieu-ve-globalgap.html">
                                                            <span>Giới thiệu về GlobalGAP</span> </a>

                                                    <li class="level1"> <a href="gioi-thieu-ve-vietgap.html">
                                                            <span>Giới thiệu về VietGAP</span> </a>

                                                    <li class="level1"> <a href="gioi-thieu-ve-pgs.html"> <span>Giới
                                                                thiệu về PGS</span> </a>

                                                    <li class="level1"> <a href="gioi-thieu-ve-lifsap.html">
                                                            <span>Giới thiệu về LifSap</span> </a>

                                                    <li class="level1"> <a href="chat-luong-quoc-te.html">
                                                            <span>Chất lượng Quốc tế</span> </a>

                                                </ul>
                                            </li>

                                            <li class="level0 level-top parent"><a class="level-top" href="he-thong-cua-hang.html"> <span>Hệ thống cửa hàng</span>
                                                </a>
                                                <ul class="level0">

                                                </ul>
                                            </li>

                                        </ul>
                                    </li>
                                </ul>
                                <div class="col-md-2 col-sm-3 cart-header">
                                    <div class="top-cart-contain">
                                        <!-- Top Cart -->
                                        <div class="mini-cart">

                                            <div data-toggle="dropdown" data-hover="dropdown" class="basket dropdown-toggle">
                                                <a href="cart.html">
                                                    <img src="../bizweb.dktcdn.net/100/150/388/themes/517622/assets/shopping-cart88b8.png" alt title>
                                                    <div class="cart-box">0</div>
                                                </a>
                                            </div>
                                            <div>
                                                <div style="display: none;" class="top-cart-content arrow_box">

                                                    <div class="block-subtitle">Sản phẩm đã cho vào giỏ hàng</div>
                                                    <ul id="cart-sidebar" class="mini-products-list">

                                                    </ul>

                                                </div>
                                            </div>
                                        </div>
                                        <!-- Top Cart -->

                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <!--End mobile-menu -->

                    <div class="menu-fill">
                        <ul id="nav" class="hidden-xs">

                            <li class="level0 parent drop-menu active"><a href="index.html"><span>Trang
                                        chủ</span></a>

                                <div>
                                    <ul class="level1">

                                    </ul>
                                </div>

                            </li>

                            <li class="level0 parent drop-menu "><a href="gioi-thieu.html"><span>Giới
                                        thiệu</span></a>

                                <div>
                                    <ul class="level1">

                                        <li class="level1 parent"><a href="gioi-thieu.html"><span>Giới
                                                    thiệu</span></a>
                                            <ul class="level2 right-sub">

                                                <li class="level2"><a href="gioi-thieu.html"><span>Giới
                                                            thiệu</span></a></li>

                                            </ul>
                                        </li>

                                    </ul>
                                </div>

                            </li>

                            <li class="level0 parent drop-menu "><a href="collections/all.html"><span>Sản phẩm</span></a>

                                <div>
                                    <ul class="level1">

                                        <li class="level1"><a href="lon-viet-nam.html"><span>Lợn
                                                    Nguyên Con</span></a></li>

                                        <li class="level1"><a href="lonhuuco.html"><span>SP Hướng
                                                    Hữu Cơ</span></a></li>

                                    </ul>
                                </div>

                            </li>

                            <li class="level0 parent drop-menu "><a href="tin-tuc.html"><span>Tin
                                        tức</span></a>

                                <div>
                                    <ul class="level1">

                                        <li class="level1 parent"><a href="tin-tuc.html"><span>Tin
                                                    Tức mới</span></a>
                                            <ul class="level2 right-sub">

                                                <li class="level2"><a href="ban-lon-muong-chinh-cong-dac-san-lon-muong-mien-bac.html"><span>Bán
                                                            lợn mường chính cống - Đặc sản lợn Mường miền Bắc</span></a></li>

                                            </ul>
                                        </li>

                                        <li class="level1"><a href="tin-nong-nghiep.html"><span>Tin
                                                    Nông nghiệp</span></a></li>

                                        <li class="level1 parent"><a href="an-toan-ve-sinh-thuc-pham.html"><span>An Toàn Vệ
                                                    Sinh Thực Phẩm</span></a>
                                            <ul class="level2 right-sub">

                                                <li class="level2"><a href="ban-lon-muong-chinh-cong-dac-san-lon-muong-mien-bac.html"><span>Bán
                                                            lợn mường chính cống - Đặc sản lợn Mường miền Bắc</span></a></li>

                                            </ul>
                                        </li>

                                        <li class="level1"><a href="nau-co.html"><span>Món Ngon Mỗi
                                                    Ngày</span></a></li>

                                        <li class="level1 parent"><a href="goc-bao-chi.html"><span>Góc
                                                    Báo Chí</span></a>
                                            <ul class="level2 right-sub">

                                                <li class="level2"><a href="chung-nhan-an-toan.html"><span>Chứng
                                                            Nhận An Toàn</span></a></li>

                                            </ul>
                                        </li>

                                    </ul>
                                </div>

                            </li>

                            <li class="level0 parent drop-menu active"><a href="index.html"><span>Chứng
                                        nhận an toàn</span></a>

                                <div>
                                    <ul class="level1">

                                        <li class="level1 parent"><a href="chung-nhan-an-toan.html"><span>Chứng
                                                    Nhận An Toàn</span></a>
                                            <ul class="level2 right-sub">

                                                <li class="level2"><a href="chung-nhan-an-toan.html"><span>Chứng
                                                            Nhận An Toàn</span></a></li>

                                                <li class="level2"><a href="gioi-thieu-ve-globalgap.html"><span>Giới
                                                            thiệu về GlobalGAP</span></a></li>

                                                <li class="level2"><a href="gioi-thieu-ve-vietgap.html"><span>Giới
                                                            thiệu về VietGAP</span></a></li>

                                                <li class="level2"><a href="gioi-thieu-ve-pgs.html"><span>Giới
                                                            thiệu về PGS</span></a></li>

                                                <li class="level2"><a href="gioi-thieu-ve-lifsap.html"><span>Giới
                                                            thiệu về LifSap</span></a></li>

                                                <li class="level2"><a href="chat-luong-quoc-te.html"><span>Chất
                                                            lượng Quốc tế</span></a></li>

                                            </ul>
                                        </li>

                                        <li class="level1"><a href="gioi-thieu-ve-globalgap.html"><span>Giới
                                                    thiệu về GlobalGAP</span></a></li>

                                        <li class="level1"><a href="gioi-thieu-ve-vietgap.html"><span>Giới
                                                    thiệu về VietGAP</span></a></li>

                                        <li class="level1"><a href="gioi-thieu-ve-pgs.html"><span>Giới
                                                    thiệu về PGS</span></a></li>

                                        <li class="level1"><a href="gioi-thieu-ve-lifsap.html"><span>Giới
                                                    thiệu về LifSap</span></a></li>

                                        <li class="level1"><a href="chat-luong-quoc-te.html"><span>Chất
                                                    lượng Quốc tế</span></a></li>

                                    </ul>
                                </div>

                            </li>

                            <li class="level0 parent drop-menu "><a href="he-thong-cua-hang.html"><span>Hệ thống cửa hàng</span></a>

                                <div>
                                    <ul class="level1">

                                    </ul>
                                </div>

                            </li>

                            <span class="phone-menu">0789 330 330</span>

                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <footer>
        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-md-4 col-sm-6">
                        <div class="blog-title">
                            <h2><a href="tin-tuc.html">TIN TỨC mới</a></h2>
                        </div>

                        <div class="row items-blog">
                            <div class="col-md-4 col-sm-5 main-article-home">
                                <div class>

                                    <a href="vi-sao-can-nam-duoc-gia-lon-rung-nguyen-con-chuan-o-hai-phong.html"><img src="../bizweb.dktcdn.net/thumb/medium/100/150/388/articles/lon-rung-nguyen-con-chuan-o-hai-phong-22706.png?v=1533176582853" alt="V&#236; sao cần nắm được gi&#225; lợn rừng nguy&#234;n con chuẩn ở Hải Ph&#242;ng?"></a>

                                </div>
                            </div>
                            <div class="col-md-8 col-sm-7">
                                <div class="text-article">
                                    <h5 class="article-title"><a href="vi-sao-can-nam-duoc-gia-lon-rung-nguyen-con-chuan-o-hai-phong.html">Vì
                                            sao cần nắm được giá lợn rừng...</a></h5>
                                    <p><span class="article-description">&nbsp;

                                            Thịt lợn rừng là thực phẩm giàu dinh dưỡng, được ưa chuộng
                                            trên thị trường....</span></p>
                                </div>
                            </div>
                        </div>

                        <div class="row items-blog">
                            <div class="col-md-4 col-sm-5 main-article-home">
                                <div class>

                                    <a href="cach-nhan-biet-lon-rung-nguyen-con-tai-hai-phong-chuan.html"><img src="../bizweb.dktcdn.net/thumb/medium/100/150/388/articles/image24866.png?v=1533176044603" alt="C&#225;ch nhận biết lợn rừng nguy&#234;n con tại Hải Ph&#242;ng chuẩn"></a>

                                </div>
                            </div>
                            <div class="col-md-8 col-sm-7">
                                <div class="text-article">
                                    <h5 class="article-title"><a href="cach-nhan-biet-lon-rung-nguyen-con-tai-hai-phong-chuan.html">Cách
                                            nhận biết lợn rừng nguyên con tại...</a></h5>
                                    <p><span class="article-description">Để mua được lợn rừng
                                            nguyên con tại Hải Phòng chuẩn, việc trang bị một...</span></p>
                                </div>
                            </div>
                        </div>

                        <div class="row items-blog">
                            <div class="col-md-4 col-sm-5 main-article-home">
                                <div class>

                                    <a href="qua-trinh-che-bien-lon-rung-nguyen-con-dac-san.html"><img src="../bizweb.dktcdn.net/thumb/medium/100/150/388/articles/lon-rung-nguyen-con-dac-san-18ff0.jpg?v=1531454088207" alt="Qu&#225; tr&#236;nh chế biến lợn rừng nguy&#234;n con đặc sản"></a>

                                </div>
                            </div>
                            <div class="col-md-8 col-sm-7">
                                <div class="text-article">
                                    <h5 class="article-title"><a href="qua-trinh-che-bien-lon-rung-nguyen-con-dac-san.html">Quá
                                            trình chế biến lợn rừng nguyên con...</a></h5>
                                    <p><span class="article-description">Lợn rừng nguyên con đặc
                                            sản là một món ăn được xếp vào hàng quý...</span></p>
                                </div>
                            </div>
                        </div>

                        <div class="row items-blog">
                            <div class="col-md-4 col-sm-5 main-article-home">
                                <div class>

                                    <a href="dac-diem-noi-troi-cua-lon-rung-nguyen-con-chinh-goc.html"><img src="../bizweb.dktcdn.net/thumb/medium/100/150/388/articles/lon-rung-nguyen-con-chinh-goc-2209f.jpg?v=1531453783620" alt="Đặc điểm nổi trội của lợn rừng nguy&#234;n con ch&#237;nh gốc"></a>

                                </div>
                            </div>
                            <div class="col-md-8 col-sm-7">
                                <div class="text-article">
                                    <h5 class="article-title"><a href="dac-diem-noi-troi-cua-lon-rung-nguyen-con-chinh-goc.html">Đặc
                                            điểm nổi trội của lợn rừng nguyên...</a></h5>
                                    <p><span class="article-description">Đặc điểm của lợn rừng
                                            nguyên con chính gốc là gì? Bài viết sau đây...</span></p>
                                </div>
                            </div>
                        </div>

                        <div class="row items-blog">
                            <div class="col-md-4 col-sm-5 main-article-home">
                                <div class>

                                    <a href="gia-lon-rung-nguyen-con-o-ha-noi-re-ma-dam-bao-chat-luong.html"><img src="../bizweb.dktcdn.net/thumb/medium/100/150/388/articles/gia-lon-muong-nguyen-con-o-ha-noi-2cf60.jpg?v=1531453393913" alt="Gi&#225; lợn rừng nguy&#234;n con ở H&#224; Nội rẻ m&#224; đảm bảo chất lượng"></a>

                                </div>
                            </div>
                            <div class="col-md-8 col-sm-7">
                                <div class="text-article">
                                    <h5 class="article-title"><a href="gia-lon-rung-nguyen-con-o-ha-noi-re-ma-dam-bao-chat-luong.html">Giá
                                            lợn rừng nguyên con ở Hà Nội...</a></h5>
                                    <p><span class="article-description">Lợn rừng nguyên con là
                                            một món ăn đã và đang được sử dụng khá...</span></p>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="col-md-4 hidden-sm hidden-xs">

                        <!-- Banner Text Block -->
                        <div class>
                            <div class="blog-title">
                                <h2><b>KẾT NỐI </b>với chúng tôi</h2>
                            </div>
                            <h3 class="widget-title"></h3>
                            <div class="widget-content"><iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Flonmuongxin%2F&amp;tabs=timeline&amp;width=300&amp;height=400&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId=663280683810689" width="300" height="400" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe></div>
                        </div>

                    </div>

                    <div class="col-md-4 col-sm-6">
                        <div class>
                            <div class="blog-title">
                                <h2><b>GÓC </b>vùng cao</h2>
                            </div>
                            <div class="flexslider2">
                                <ul class="slides">
                                    <li>
                                        <a href="#">
                                            <img src="../bizweb.dktcdn.net/100/150/388/themes/517622/assets/slide388b8.jpg" />
                                        </a>
                                    </li>
                                    <li> <a href="#">
                                            <img src="../bizweb.dktcdn.net/100/150/388/themes/517622/assets/slide488b8.jpg" />
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <img src="../bizweb.dktcdn.net/100/150/388/themes/517622/assets/slide588b8.jpg" />
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        

        <div class="footer-inner">
            <div class="container">
                <div class="container-footer">
                    <div class="col-md-3 col-sm-12 col-xs-12 col-lg-3">
                        <div class="footer-column-1 pull-left">
                            <div class="footer-logo"><a href="index.html" title="LỢN MƯỜNG XỊN.com">

                                    <h4>LỢN MƯỜNG XỊN.com</h4>

                                </a></div>
                            <p>Với sản phẩm đa dạng cùng với tiêu chí
                                "Vì sức khỏe cộng đồng" chúng tôi cam kết bán hàng với giá
                                bình ổn, hợp lý, chất lượng tốt nhất đến khách hàng! Hãy lựa
                                chọn chúng tôi là đối tác của bạn để cảm nhận giá trị hợp tác
                                kinh doanh hiệu quả và thành công nhất!. </p>
                            <div><img alt="LỢN MƯỜNG XỊN.com" src="../bizweb.dktcdn.net/100/150/388/themes/517622/assets/logo-white88b8.png"></div>

                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 col-footer-border">
                        <div class="footer-column pull-left">
                            <h4>Hỗ trợ khách hàng</h4>
                            <ul class="links">

                                <li><a href="chinh-sach-chung-ho-tro-dai-ly.html" title="Chính Sách Hỗ Trợ Đại Lý">Chính Sách Hỗ Trợ Đại Lý</a></li>

                                <li><a href="chinh-sach.html" title="Điều Khoản Bảo Mật">Điều
                                        Khoản Bảo Mật</a></li>

                            </ul>
                            <div class="so-col-2">
                                <h3>HOTLINE</h3>
                                <a href="tel:0789 330 330"><span><img src="../bizweb.dktcdn.net/100/150/388/themes/517622/assets/call-icon88b8.png">Hỗ
                                        trợ: 0789 330 330</span></a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 col-footer-border">
                        <div class="footer-column pull-left">
                            <h4>Danh mục sản phẩm</h4>
                            <ul class="links">

                                <li><a href="index.html" title="Trang chủ">Trang chủ</a></li>

                                <li><a href="gioi-thieu.html" title="Giới thiệu">Giới thiệu</a></li>

                                <li><a href="collections/all.html" title="Sản phẩm">Sản phẩm</a></li>

                                <li><a href="tin-tuc.html" title="Tin tức">Tin tức</a></li>

                                <li><a href="index.html" title="Chứng nhận an toàn">Chứng nhận
                                        an toàn</a></li>

                                <li><a href="he-thong-cua-hang.html" title="Hệ thống cửa hàng">Hệ
                                        thống cửa hàng</a></li>

                            </ul>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 col-footer-border">
                        <div class="footer-column-last pull-left">
                            <h4>Liên hệ</h4>

                            <address>
                                <i class="add-icon"></i>Hà Nội | Hòa Bình | Hải Phòng | Lai
                                Châu | Hà Giang
                            </address>
                            <div class="phone-footer"><a href="tel: (+84) 789.330.330"><i class="phone-icon">&nbsp;</i>(+84) 789.330.330</a></div>
                            <div class="email-footer"><a href="mailto: phamnangtoany@gmail.com"><i class="email-icon">&nbsp;</i>phamnangtoany@gmail.com</a></div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container">
                    <div class=" container-footer2">
                        <div class="container-footer2-row">

                            <div class="col-sm-7 col-xs-12 company-links">
                                <ul class="socialls clearfix">

                                    <li><a target="_blank" href="https://www.facebook.com/lonmuongxin" title="LỢN MƯỜNG XỊN.com">
                                            <i class="fa fa-facebook" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li><a target="_blank" href="https://www.youtube.com/channel/UCs6CuNF9DuPb5sKH1pJDt1g?view_as=subscriber" title="LỢN MƯỜNG XỊN.com">
                                            <i class="fa fa-youtube" aria-hidden="true"></i>
                                        </a>
                                    </li>

                                </ul>
                            </div>
                            <div class="col-sm-5 col-xs-12 coppyright"> Copyright &copy;
                                2006.All Rights Reserved</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="modal fade hidden-xs" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><img src="../bizweb.dktcdn.net/100/150/388/themes/517622/assets/cl88b8.png" /></button>
                </div>
                <div class="modal-body">
                    <iframe width="600" height="321" src="https://www.youtube.com/embed/QeqBLJEUcIY" frameborder="0" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>

    <script src="../js/lonrunglai/common88b8.js" type="text/javascript"></script>
    <script src="../js/lonrunglai/jquery-gmaps-latlon-picker88b8.js" type="text/javascript"></script>
    <script src="../js/lonrunglai/jquery.nanoscroller.min88b8.js" type="text/javascript"></script>
    <script language="javascript" type="text/javascript">
        $(document).ready(function() {
            setTimeout('$(".nano").nanoScroller()', 500);
        });
    </script>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,300,700,800,400,600" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="../css/lonrunglai/font-awesome.min.css">
    <script src="../js/lonrunglai/bootstrap.min88b8.js" type="text/javascript"></script>
    <script src="../js/lonrunglai/jquery.flexslider88b8.js" type="text/javascript"></script>
    <script src="../js/lonrunglai/cloud-zoom88b8.js" type="text/javascript"></script>
    <script src="../js/lonrunglai/owl.carousel.min88b8.js" type="text/javascript"></script>
    <script src="../js/lonrunglai/parallax88b8.js" type="text/javascript"></script>
    <script src="../js/lonrunglai/api.jquery.js" type="text/javascript"></script>
    <script src="../js/lonrunglai/jgrowl88b8.js" type="text/javascript"></script>
    <script src="../js/lonrunglai/cs.script88b8.js" type="text/javascript"></script>
    <script src="../js/lonrunglai/showroom88b8.js" type="text/javascript"></script>
    <script type="text/javascript">
        Bizweb.updateCartFromForm = function(cart, cart_summary_id, cart_count_id) {

            if ((typeof cart_summary_id) === 'string') {
                var cart_summary = jQuery(cart_summary_id);
                if (cart_summary.length) {
                    // Start from scratch.
                    cart_summary.empty();
                    // Pull it all out.        
                    jQuery.each(cart, function(key, value) {
                        if (key === 'items') {

                            var table = jQuery(cart_summary_id);
                            

                        }
                    });

                }
            }
            updateCartDesc(cart);
        }


        function updateCartDesc(data) {
            var $cartLinkText = $('.mini-cart .cart-box #cart-total, aside.sidebar .block-cart .amount a'),

                
            $('.top-cart-content .top-subtotal .price, aside.sidebar .block-cart .subtotal .price').html($cartPrice);
        }
        Bizweb.onCartUpdate = function(cart) {
            Bizweb.updateCartFromForm(cart, '.top-cart-content .mini-products-list', 'shopping-cart');
        };
        $(window).load(function() {
            // Let's get the cart and show what's in it in the cart box.  
            Bizweb.getCart(function(cart) {
                Bizweb.updateCartFromForm(cart, '.top-cart-content .mini-products-list');
            });
        });
    </script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 0;"></span></a>

    <script>
        // Can also be used with $(document).ready()
        $(window).load(function() {
            $('.flexslider2').flexslider({
                animation: "slide",
                controlNav: false, //Boolean: Create navigation for paging control of each clide? Note: Leave true for manualControls usage
                directionNav: true, //Boolean: Create navigation for previous/next navigation? (true/false)
                nextText: '<img src="//bizweb.dktcdn.net/100/150/388/themes/517622/assets/r.png" />', //String: Set the text for the "previous" directionNav item
                prevText: '<img src="//bizweb.dktcdn.net/100/150/388/themes/517622/assets/l.png" />',
            });

        });
    </script>
    <a href="tel:0789 330 330" class="visible-xs suntory-alo-phone suntory-alo-green" id="suntory-alo-phoneIcon" style="left: 0px; bottom: -25px;">
        <div class="suntory-alo-ph-circle"></div>
        <div class="suntory-alo-ph-circle-fill"></div>
        <div class="suntory-alo-ph-img-circle"><i class="fa fa-phone"></i></div>
    </a>
    <style>
        .suntory-alo-phone {
            background-color: transparent;
            cursor: pointer;
            height: 120px;
            position: fixed;
            transition: visibility 0.5s ease 0s;
            width: 120px;
            z-index: 200000 !important;
        }

        .suntory-alo-ph-circle {
            animation: 1.2s ease-in-out 0s normal none infinite running suntory-alo-circle-anim;
            background-color: transparent;
            border: 2px solid rgba(30, 30, 30, 0.4);
            border-radius: 100%;
            height: 100px;
            left: 0px;
            opacity: 0.1;
            position: absolute;
            top: 0px;
            transform-origin: 50% 50% 0;
            transition: all 0.5s ease 0s;
            width: 100px;
        }

        .suntory-alo-ph-circle-fill {
            animation: 2.3s ease-in-out 0s normal none infinite running suntory-alo-circle-fill-anim;
            border: 2px solid transparent;
            border-radius: 100%;
            height: 70px;
            left: 15px;
            position: absolute;
            top: 15px;
            transform-origin: 50% 50% 0;
            transition: all 0.5s ease 0s;
            width: 70px;
        }

        .suntory-alo-ph-img-circle {
            /* animation: 1s ease-in-out 0s normal none infinite running suntory-alo-circle-img-anim; */
            border: 2px solid transparent;
            border-radius: 100%;
            height: 50px;
            left: 25px;
            opacity: 0.7;
            position: absolute;
            top: 25px;
            transform-origin: 50% 50% 0;
            width: 50px;
        }

        .suntory-alo-phone.suntory-alo-hover,
        .suntory-alo-phone:hover {
            opacity: 1;
        }

        .suntory-alo-phone.suntory-alo-active .suntory-alo-ph-circle {
            animation: 1.1s ease-in-out 0s normal none infinite running suntory-alo-circle-anim !important;
        }

        .suntory-alo-phone.suntory-alo-static .suntory-alo-ph-circle {
            animation: 2.2s ease-in-out 0s normal none infinite running suntory-alo-circle-anim !important;
        }

        .suntory-alo-phone.suntory-alo-hover .suntory-alo-ph-circle,
        .suntory-alo-phone:hover .suntory-alo-ph-circle {
            border-color: #00aff2;
            opacity: 0.5;
        }

        .suntory-alo-phone.suntory-alo-green.suntory-alo-hover .suntory-alo-ph-circle,
        .suntory-alo-phone.suntory-alo-green:hover .suntory-alo-ph-circle {
            border-color: #EB278D;
            opacity: 1;
        }

        .suntory-alo-phone.suntory-alo-green .suntory-alo-ph-circle {
            border-color: #bfebfc;
            opacity: 1;
        }

        .suntory-alo-phone.suntory-alo-hover .suntory-alo-ph-circle-fill,
        .suntory-alo-phone:hover .suntory-alo-ph-circle-fill {
            background-color: rgba(0, 175, 242, 0.9);
        }

        .suntory-alo-phone.suntory-alo-green.suntory-alo-hover .suntory-alo-ph-circle-fill,
        .suntory-alo-phone.suntory-alo-green:hover .suntory-alo-ph-circle-fill {
            background-color: #EB278D;
        }

        .suntory-alo-phone.suntory-alo-green .suntory-alo-ph-circle-fill {
            background-color: rgba(0, 175, 242, 0.9);
        }

        .suntory-alo-phone.suntory-alo-hover .suntory-alo-ph-img-circle,
        .suntory-alo-phone:hover .suntory-alo-ph-img-circle {
            background-color: #00aff2;
        }

        .suntory-alo-phone.suntory-alo-green.suntory-alo-hover .suntory-alo-ph-img-circle,
        .suntory-alo-phone.suntory-alo-green:hover .suntory-alo-ph-img-circle {
            background-color: #EB278D;
        }

        .suntory-alo-phone.suntory-alo-green .suntory-alo-ph-img-circle {
            background-color: #00aff2;
        }

        @keyframes  suntory-alo-circle-anim {
            0% {
                opacity: 0.1;
                transform: rotate(0deg) scale(0.5) skew(1deg);
            }

            30% {
                opacity: 0.5;
                transform: rotate(0deg) scale(0.7) skew(1deg);
            }

            100% {
                opacity: 0.6;
                transform: rotate(0deg) scale(1) skew(1deg);
            }
        }

        @keyframes  suntory-alo-circle-img-anim {
            0% {
                transform: rotate(0deg) scale(1) skew(1deg);
            }

            10% {
                transform: rotate(-25deg) scale(1) skew(1deg);
            }

            20% {
                transform: rotate(25deg) scale(1) skew(1deg);
            }

            30% {
                transform: rotate(-25deg) scale(1) skew(1deg);
            }

            40% {
                transform: rotate(25deg) scale(1) skew(1deg);
            }

            50% {
                transform: rotate(0deg) scale(1) skew(1deg);
            }

            100% {
                transform: rotate(0deg) scale(1) skew(1deg);
            }
        }

        @keyframes  suntory-alo-circle-fill-anim {
            0% {
                opacity: 0.2;
                transform: rotate(0deg) scale(0.7) skew(1deg);
            }

            50% {
                opacity: 0.2;
                transform: rotate(0deg) scale(1) skew(1deg);
            }

            100% {
                opacity: 0.2;
                transform: rotate(0deg) scale(0.7) skew(1deg);
            }
        }

        .suntory-alo-ph-img-circle i {
            animation: 1s ease-in-out 0s normal none infinite running suntory-alo-circle-img-anim;
            font-size: 30px;
            line-height: 50px;
            padding-left: 10px;
            color: #fff;
        }

        /*=================== End phone ring ===============*/
        @keyframes  suntory-alo-ring-ring {
            0% {
                transform: rotate(0deg) scale(1) skew(1deg);
            }

            10% {
                transform: rotate(-25deg) scale(1) skew(1deg);
            }

            20% {
                transform: rotate(25deg) scale(1) skew(1deg);
            }

            30% {
                transform: rotate(-25deg) scale(1) skew(1deg);
            }

            40% {
                transform: rotate(25deg) scale(1) skew(1deg);
            }

            50% {
                transform: rotate(0deg) scale(1) skew(1deg);
            }

            100% {
                transform: rotate(0deg) scale(1) skew(1deg);
            }
        }
    </style>
</body>

<!-- Mirrored from lonmuongxin.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 Jul 2023 07:28:13 GMT -->

</html><?php /**PATH D:\Github\web_ocoop\resources\views/lonrunglaikyson/views/layouts/trangchu.blade.php ENDPATH**/ ?>