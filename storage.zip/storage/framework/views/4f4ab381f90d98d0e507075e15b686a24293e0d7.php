
<?php $__env->startSection('content'); ?>



<main id="main" class>
    <div id="co
ntent" role="main" class="content-area">
        <div id="gap-1492630812" class="gap-element clearfix" style="display: block; height: auto">
            <style>
                #gap-1492630812 {
                    padding-top: 20px;
                }
            </style>
        </div>
        <div class="row row-small slider" id="row-567718893">

            <div id="col-377529967" class="col medium-9 small-12 large-12">
                <div class="col-inner">
                    <div class="slider-wrapper relative" id="slider-553567688">
                        <div class="slider slider-nav-dots-dashes slider-nav-simple slider-nav-normal slider-nav-light slider-style-normal slider-show-nav" data-flickity-options='{
 "cellAlign": "center",
 "imagesLoaded": true,
 "lazyLoad": 1,
 "freeScroll": false,
 "wrapAround": true,
 "autoPlay": 2000,
 "pauseAutoPlayOnHover" : false,
 "prevNextButtons": true,
 "contain" : true,
 "adaptiveHeight" : true,
 "dragThreshold" : 10,
 "percentPosition": true,
 "pageDots": false,
 "rightToLeft": false,
 "draggable": true,
 "selectedAttraction": 0.1,
 "parallax" : 0,
 "friction": 0.6        }'>
                            <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_807716801">
                                <div class="img-inner dark">
                                    <noscript><img style="height: 575px;" width="1020" height="575" src="../images/4d464c03b27847261e69.jpg" class="attachment-large size-large" alt srcset="
                            " sizes="(max-width: 1020px) 100vw, 1020px" /></noscript><img width="1020" height="575" style="height: 575px;" src="../images/4d464c03b27847261e69.jpg" data-src="../images/4d464c03b27847261e69.jpg" class="lazyload attachment-large size-large" data-sizes="(max-width: 1020px) 100vw, 1020px" />
                                </div>
                                <style>
                                    #image_807716801 {
                                        width: 100%;
                                    }
                                </style>
                            </div>
                            <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1176056666">
                                <div class="img-inner dark">
                                    <noscript><img style="height: 575px;" width="1020" height="575" src="../images/1626879400263_image (38).jpeg" class="attachment-large size-large" alt srcset="" sizes="(max-width: 1020px) 100vw, 1020px" /></noscript><img style="height: 575px;" width="1020" height="575" src="../images/1626879400263_image (38).jpeg" data-src="../images/1626879400263_image (38).jpeg" class="lazyload attachment-large size-large" data-sizes="(max-width: 1020px) 100vw, 1020px" />
                                </div>
                                <style>
                                    #image_1176056666 {
                                        width: 100%;
                                    }
                                </style>
                            </div>
                            <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_80268220">
                                <div class="img-inner dark">
                                    <noscript><img width="1020" height="575" style="height: 575px;" src="../images/ốc_buou_đen.jpg" class="attachment-large size-large" alt srcset="" sizes="(max-width: 1020px) 100vw, 1020px" /></noscript><img width="1020" height="575" style="height: 575px;" src="../images/ốc_buou_đen.jpg" data-src="../images/ốc_buou_đen.jpg" class="lazyload attachment-large size-large" data-sizes="(max-width: 1020px) 100vw, 1020px" />
                                </div>
                                <style>
                                    #image_80268220 {
                                        width: 100%;
                                    }
                                </style>
                            </div>
                            <!-- <div class="img has-hover x md-x lg-x y md-y lg-y"
                                id="image_2122691198">
                                <div class="img-inner dark">
                                    <noscript><img width="1020" height="575"
                                            src="wp-content/uploads/2022/06/4-1024x577.png"
                                            class="attachment-large size-large"
                                            alt srcset="
                              https://traiocgiong.com/wp-content/uploads/2022/06/4-1024x577.png 1024w,
                              https://traiocgiong.com/wp-content/uploads/2022/06/4-300x169.png   300w,
                              https://traiocgiong.com/wp-content/uploads/2022/06/4-768x433.png   768w,
                              https://traiocgiong.com/wp-content/uploads/2022/06/4-1536x865.png 1536w,
                              https://traiocgiong.com/wp-content/uploads/2022/06/4-600x338.png   600w,
                              https://traiocgiong.com/wp-content/uploads/2022/06/4.png          1640w
                            " sizes="(max-width: 1020px) 100vw, 1020px" /></noscript><img
                                        width="1020" height="575"
                                        src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%201020%20575%22%3E%3C/svg%3E"
                                        data-src="https://traiocgiong.com/wp-content/uploads/2022/06/4-1024x577.png"
                                        class="lazyload attachment-large size-large"
                                        alt
                                        data-srcset="https://traiocgiong.com/wp-content/uploads/2022/06/4-1024x577.png 1024w, https://traiocgiong.com/wp-content/uploads/2022/06/4-300x169.png 300w, https://traiocgiong.com/wp-content/uploads/2022/06/4-768x433.png 768w, https://traiocgiong.com/wp-content/uploads/2022/06/4-1536x865.png 1536w, https://traiocgiong.com/wp-content/uploads/2022/06/4-600x338.png 600w, https://traiocgiong.com/wp-content/uploads/2022/06/4.png 1640w"
                                        data-sizes="(max-width: 1020px) 100vw, 1020px" />
                                </div>
                                <style>
                                    #image_2122691198 {
                                        width: 100%;
                                    }
                                </style>
                            </div> -->
                        </div>
                        <div class="loading-spin dark large centered"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row row-small" id="row-35271347">
            <div id="col-1398443493" class="col hide-for-small medium-4 small-12 large-4">
                <div class="col-inner">
                    <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1705108428">
                        <div class="img-inner image-cover dark" style="padding-top: 50%">
                            <noscript><img width="736" height="368" style="height:368px;" src="../images/snapedit_1690339749568.jpg" class="attachment-original size-original" alt srcset="../images/snapedit_1690339749568.jpg
                        " sizes="(max-width: 736px) 100vw, 736px" /></noscript><img width="736" height="368" style="height:368px;" src="../images/snapedit_1690339749568.jpg" data-src="../images/snapedit_1690339749568.jpg" class="lazyload attachment-original size-original" data-sizes="(max-width: 736px) 100vw, 736px" />
                        </div>
                        <style>
                            #image_1705108428 {
                                width: 100%;
                            }
                        </style>
                    </div>
                </div>
            </div>
            <div id="col-274766577" class="col hide-for-small medium-4 small-12 large-4">
                <div class="col-inner">
                    <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1724683439">
                        <div class="img-inner image-cover dark" style="padding-top: 50%">
                            <noscript><img width="736" height="368" style="height: 368px;" src="../images/snapedit_1690339898369.jpg" class="attachment-original size-original" alt srcset="../images/snapedit_1690339898369.jpg
                        " sizes="(max-width: 736px) 100vw, 736px" /></noscript><img width="736" height="368" style="height: 368px;" src="../images/snapedit_1690339898369.jpg" data-src="../images/snapedit_1690339898369.jpg" class="lazyload attachment-original size-original" data-sizes="(max-width: 736px) 100vw, 736px" />
                        </div>
                        <style>
                            #image_1724683439 {
                                width: 100%;
                            }
                        </style>
                    </div>
                </div>
            </div>
            <div id="col-950892199" class="col hide-for-small medium-4 small-12 large-4">
                <div class="col-inner">
                    <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_762243016">
                        <div class="img-inner image-cover dark" style="padding-top: 50%">
                            <noscript><img width="736" height="368" style="height: 368px;" src="../images/snapedit_1690339936920.jpg" class="attachment-original size-original" alt srcset="../images/snapedit_1690339936920.jpg
                        " sizes="(max-width: 736px) 100vw, 736px" /></noscript><img width="736" height="368" style="height: 368px;" src="../images/snapedit_1690339936920.jpg" data-src="../images/snapedit_1690339936920.jpg" class="lazyload attachment-original size-original" data-sizes="(max-width: 736px) 100vw, 736px" />
                        </div>
                        <style>
                            #image_762243016 {
                                width: 100%;
                            }
                        </style>
                    </div>
                </div>
            </div>
        </div>
        <section class="section section-san-pham" id="section_556839869">
            <div class="bg section-bg fill bg-fill bg-loaded"></div>
            <div class="section-content relative">
                <div class="row row-small sp-ban-chay" id="row-349721090">
                    <div id="col-2084673702" class="col hide-for-small small-12 large-12">
                        <div class="col-inner">
                            <h3 class="tieu-de"><b></b>SẢN PHẨM BÁN CHẠY<b></b></h3>
                            <div id="gap-879088675" class="gap-element clearfix" style="display: block; height: auto">
                                <style>
                                    #gap-879088675 {
                                        padding-top: 20px;
                                    }
                                </style>
                            </div>
                            <div class="row large-columns-4 medium-columns-3 small-columns-2 row-normal">
                                <?php $__currentLoopData = $sanphambanchay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spbc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product-small col has-hover product type-product post-1151 status-publish first instock product_cat-oc-1-tuan-tuoi product_cat-oc-giong has-post-thumbnail sale shipping-taxable purchasable product-type-simple">
                                    <div class="col-inner">
                                        <div class="badge-container absolute left top z-1">
                                            <div class="callout badge badge-square">
                                                <!-- <div
                                                    class="badge-inner secondary on-sale">
                                                    <span class="onsale">-13%</span>
                                                </div> -->
                                            </div>
                                        </div>
                                        <div class="product-small box">
                                            <div class="box-image">
                                                <div class="image-none">
                                                    <a href="/chi-tiet-san-pham/<?php echo e($spbc->slug); ?>">
                                                        <noscript><img style="width:300px; height:300px;" src="/storage/<?php echo e($spbc->thumbnail); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt srcset="
                                                        /storage/<?php echo e($spbc->thumbnail); ?>" sizes="(max-width: 300px) 100vw, 300px" />
                                                        </noscript>
                                                        <img style="width:300px; height:300px;" src="/storage/<?php echo e($spbc->thumbnail); ?>" data-src="/storage/<?php echo e($spbc->thumbnail); ?> 100w" data-sizes="(max-width: 300px) 100vw, 300px" />
                                                    </a>
                                                </div>
                                                <div class="image-tools is-small top right show-on-hover"></div>
                                                <div class="image-tools is-small hide-for-small bottom left show-on-hover">
                                                </div>
                                                <div class="image-tools grid-tools text-center hide-for-small bottom hover-slide-in show-on-hover">
                                                </div>
                                            </div>
                                            <div class="box-text box-text-products text-center grid-style-2">
                                                <div class="title-wrapper">
                                                    <p class="name product-title woocommerce-loop-product__title">
                                                        <a href="/chi-tiet-san-pham/<?php echo e($spbc->slug); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><?php echo e($spbc->title); ?></a>
                                                    </p>
                                                </div>
                                                <div class="price-wrapper">
                                                    <span class="price">
                                                        <ins><span class="woocommerce-Price-amount amount"><bdi><?php echo e($spbc->price); ?><span class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span></ins></span>
                                                </div>
                                                <div class="add-to-cart-button">
                                                    <!-- <a href="indexb95e.html?add-to-cart=1151" data-quantity="1" class="primary is-small mb-0 button product_type_simple add_to_cart_button ajax_add_to_cart is-flat" data-product_id="1151" data-product_sku aria-label="Thêm &ldquo;Ốc Bươu Đen Giống 2 Tuần Tuổi&rdquo; vào giỏ hàng" rel="nofollow">Mua hàng</a> -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    </div>
                    <div id="col-1437763984" class="col show-for-small small-12 large-12">
                        <div class="col-inner">
                            <h3 class="tieu-de"><b></b>SẢN PHẨM BÁN CHẠY<b></b></h3>
                            <div id="gap-1928329202" class="gap-element clearfix" style="display: block; height: auto">
                                <style>
                                    #gap-1928329202 {
                                        padding-top: 20px;
                                    }
                                </style>
                            </div>
                            <div class="row large-columns-3 medium-columns- small-columns-2 row-normal slider row-slider slider-nav-reveal slider-nav-push" data-flickity-options='{"imagesLoaded": true, "groupCells": "100%", "dragThreshold" : 5, "cellAlign": "left","wrapAround": true,"prevNextButtons": true,"percentPosition": true,"pageDots": false, "rightToLeft": false, "autoPlay" : 4000}'>
                            <?php $__currentLoopData = $sanphambanchay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spbc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product-small col has-hover product type-product post-1789 status-publish instock product_cat-oc-giong has-post-thumbnail sale shipping-taxable purchasable product-type-simple">
                                    <div class="col-inner">
                                        <div class="badge-container absolute left top z-1">
                                            <div class="callout badge badge-square">
                                                <!-- <div
                                                    class="badge-inner secondary on-sale">
                                                    <span class="onsale">-13%</span>
                                                </div> -->
                                            </div>
                                        </div>
                                        <div class="product-small box">
                                            <div class="box-image">
                                                <div class="image-none">
                                                    <a href="/chi-tiet-san-pham/<?php echo e($spbc->slug); ?>">
                                                        <noscript><img style="width:300px; height:300px;" src="/storage/<?php echo e($spbc->thumbnail); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt srcset="
                                                        /storage/<?php echo e($spbc->thumbnail); ?>" sizes="(max-width: 300px) 100vw, 300px" />
                                                        </noscript>
                                                        <img style="width:300px; height:300px;" src="/storage/<?php echo e($spbc->thumbnail); ?>" data-src="/storage/<?php echo e($spbc->thumbnail); ?> 100w" data-sizes="(max-width: 300px) 100vw, 300px" />
                                                    </a>
                                                </div>
                                                <div class="image-tools is-small top right show-on-hover"></div>
                                                <div class="image-tools is-small hide-for-small bottom left show-on-hover">
                                                </div>
                                                <div class="image-tools grid-tools text-center hide-for-small bottom hover-slide-in show-on-hover">
                                                </div>
                                            </div>
                                            <div class="box-text box-text-products text-center grid-style-2">
                                                <div class="title-wrapper">
                                                    <p class="name product-title woocommerce-loop-product__title">
                                                        <a href="/chi-tiet-san-pham/<?php echo e($spbc->slug); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><?php echo e($spbc->title); ?></a>
                                                    </p>
                                                </div>
                                                <div class="price-wrapper">
                                                    <span class="price">
                                                        <ins><span class="woocommerce-Price-amount amount"><bdi><?php echo e($spbc->price); ?><span class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span></ins></span>
                                                </div>
                                                <div class="add-to-cart-button">
                                                    <!-- <a href="indexb95e.html?add-to-cart=1151" data-quantity="1" class="primary is-small mb-0 button product_type_simple add_to_cart_button ajax_add_to_cart is-flat" data-product_id="1151" data-product_sku aria-label="Thêm &ldquo;Ốc Bươu Đen Giống 2 Tuần Tuổi&rdquo; vào giỏ hàng" rel="nofollow">Mua hàng</a> -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <style>
                #section_556839869 {
                    padding-top: 30px;
                    padding-bottom: 30px;
                }
            </style>
        </section>
        <section class="section section-san-pham" id="section_77263515">
            <div class="bg section-bg fill bg-fill bg-loaded"></div>
            <div class="section-content relative">
                <div class="row row-small sp-ban-chay" id="row-307832911">
                    <div id="col-1888619084" class="col hide-for-small small-12 large-12">
                        <div class="col-inner">
                            <h3 class="tieu-de"><b></b>SẢN PHẨM MỚI<b></b></h3>
                            <div id="gap-1610208312" class="gap-element clearfix" style="display: block; height: auto">
                                <style>
                                    #gap-1610208312 {
                                        padding-top: 20px;
                                    }
                                </style>
                            </div>
                            <div class="row large-columns-4 medium-columns-3 small-columns-2 row-normal">
                                <?php $__currentLoopData = $sanphammoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product-small col has-hover product type-product post-1789 status-publish first instock product_cat-oc-giong has-post-thumbnail sale shipping-taxable purchasable product-type-simple">
                                    <div class="col-inner">
                                        <div class="badge-container absolute left top z-1">
                                            <div class="callout badge badge-square">
                                                <!-- <div class="badge-inner secondary on-sale">
                                                    <span class="onsale">-8%</span>
                                                </div> -->
                                            </div>
                                        </div>
                                        <div class="product-small box">
                                            <div class="box-image">
                                                <div class="image-none">
                                                    <a href="/chi-tiet-san-pham/<?php echo e($spm->slug); ?>">
                                                        <noscript><img style="width:300px; height:300px;"  src="/storage/<?php echo e($spm->thumbnail); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt srcset="
                                                        /storage/<?php echo e($spm->thumbnail); ?>

                                      " sizes="(max-width: 300px) 100vw, 300px" /></noscript><img style="width:300px; height:300px;" src="/storage/<?php echo e($spm->thumbnail); ?>" class="lazyload attachment-woocommerce_thumbnail size-woocommerce_thumbnail"  data-sizes="(max-width: 300px) 100vw, 300px" />
                                                    </a>
                                                </div>
                                                <div class="image-tools is-small top right show-on-hover"></div>
                                                <div class="image-tools is-small hide-for-small bottom left show-on-hover">
                                                </div>
                                                <div class="image-tools grid-tools text-center hide-for-small bottom hover-slide-in show-on-hover">
                                                </div>
                                            </div>
                                            <div class="box-text box-text-products text-center grid-style-2">
                                                <div class="title-wrapper">
                                                    <p class="name product-title woocommerce-loop-product__title">
                                                        <a href="/chi-tiet-san-pham/<?php echo e($spm->slug); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><?php echo e($spm->title); ?></a>
                                                    </p>
                                                </div>
                                                <div class="price-wrapper">
                                                    
                                                    <span class="price">
                                                        <ins><span class="woocommerce-Price-amount amount"><bdi><?php echo e($spm->price); ?><span class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span></ins></span>
                                                </div>
                                                <div class="add-to-cart-button">
                                                    <!-- <a href="indexb028.html?add-to-cart=1789" data-quantity="1" class="primary is-small mb-0 button product_type_simple add_to_cart_button ajax_add_to_cart is-flat" data-product_id="1789" data-product_sku aria-label="Thêm &ldquo;Ốc Bươu Đen Giống 5 Tuần Tuổi&rdquo; vào giỏ hàng" rel="nofollow">Mua hàng</a> -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div id="col-30443557" class="col show-for-small small-12 large-12">
                        <div class="col-inner">
                            <h3 class="tieu-de"><b></b>SẢN PHẨM MỚI<b></b></h3>
                            <div id="gap-212970399" class="gap-element clearfix" style="display: block; height: auto">
                                <style>
                                    #gap-212970399 {
                                        padding-top: 20px;
                                    }
                                </style>
                            </div>
                            <div class="row large-columns-3 medium-columns- small-columns-2 row-normal slider row-slider slider-nav-reveal slider-nav-push" data-flickity-options='{"imagesLoaded": true, "groupCells": "100%", "dragThreshold" : 5, "cellAlign": "left","wrapAround": true,"prevNextButtons": true,"percentPosition": true,"pageDots": false, "rightToLeft": false, "autoPlay" : 4000}'>
                            <?php $__currentLoopData = $sanphammoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product-small col has-hover product type-product post-1789 status-publish first instock product_cat-oc-giong has-post-thumbnail sale shipping-taxable purchasable product-type-simple">
                                    <div class="col-inner">
                                        <div class="badge-container absolute left top z-1">
                                            <div class="callout badge badge-square">
                                                <!-- <div class="badge-inner secondary on-sale">
                                                    <span class="onsale">-8%</span>
                                                </div> -->
                                            </div>
                                        </div>
                                        <div class="product-small box">
                                            <div class="box-image">
                                                <div class="image-none">
                                                    <a href="/chi-tiet-san-pham/<?php echo e($spm->slug); ?>">
                                                        <noscript><img style="width:300px; height:300px;"  src="/storage/<?php echo e($spm->thumbnail); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt srcset="
                                                        /storage/<?php echo e($spm->thumbnail); ?>

                                      " sizes="(max-width: 300px) 100vw, 300px" /></noscript><img style="width:300px; height:300px;" src="/storage/<?php echo e($spm->thumbnail); ?>" class="lazyload attachment-woocommerce_thumbnail size-woocommerce_thumbnail"  data-sizes="(max-width: 300px) 100vw, 300px" />
                                                    </a>
                                                </div>
                                                <div class="image-tools is-small top right show-on-hover"></div>
                                                <div class="image-tools is-small hide-for-small bottom left show-on-hover">
                                                </div>
                                                <div class="image-tools grid-tools text-center hide-for-small bottom hover-slide-in show-on-hover">
                                                </div>
                                            </div>
                                            <div class="box-text box-text-products text-center grid-style-2">
                                                <div class="title-wrapper">
                                                    <p class="name product-title woocommerce-loop-product__title">
                                                        <a href="/chi-tiet-san-pham/<?php echo e($spm->slug); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><?php echo e($spm->title); ?></a>
                                                    </p>
                                                </div>
                                                <div class="price-wrapper">
                                                    
                                                    <span class="price">
                                                        <ins><span class="woocommerce-Price-amount amount"><bdi><?php echo e($spm->price); ?><span class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span></ins></span>
                                                </div>
                                                <div class="add-to-cart-button">
                                                    <!-- <a href="indexb028.html?add-to-cart=1789" data-quantity="1" class="primary is-small mb-0 button product_type_simple add_to_cart_button ajax_add_to_cart is-flat" data-product_id="1789" data-product_sku aria-label="Thêm &ldquo;Ốc Bươu Đen Giống 5 Tuần Tuổi&rdquo; vào giỏ hàng" rel="nofollow">Mua hàng</a> -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <style>
                #section_77263515 {
                    padding-top: 30px;
                    padding-bottom: 30px;
                }
            </style>
        </section>
        
        <section class="section section-san-pham" id="section_1854132819">
            <div class="bg section-bg fill bg-fill bg-loaded"></div>
            <div class="section-content relative">
                <div class="row row-small sp-ban-chay" id="row-1649340230">
                    <div id="col-928367647" class="col small-12 large-12">
                        <div class="col-inner">
                            <h3 class="tieu-de"><b></b>ỐC GIỐNG<b></b></h3>
                            <div id="gap-1895432412" class="gap-element clearfix" style="display: block; height: auto">
                                <style>
                                    #gap-1895432412 {
                                        padding-top: 20px;
                                    }
                                </style>
                            </div>
                        </div>
                    </div>
                    <div id="col-942103464" class="col hide-for-small medium-9 small-12 large-9">
                        <div class="col-inner">
                            <div class="row large-columns-3 medium-columns- small-columns-2 row-normal">
                                
                                <?php $__currentLoopData = $ocgiong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $og): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product-small col has-hover product type-product post-1789 status-publish instock product_cat-oc-giong has-post-thumbnail sale shipping-taxable purchasable product-type-simple">
                                    <div class="col-inner">
                                        <div class="badge-container absolute left top z-1">
                                            <div class="callout badge badge-square">
                                                <!-- <div class="badge-inner secondary on-sale">
                                                    <span class="onsale">-8%</span>
                                                </div> -->
                                            </div>
                                        </div>
                                        <div class="product-small box">
                                            <div class="box-image">
                                                <div class="image-none">
                                                    <a href="chi-tiet-san-pham/<?php echo e($og->slug); ?>">
                                                        <noscript><img style="width:300px; height:300px;" src="/storage/<?php echo e($og->thumbnail); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt srcset="
                                                        /storage/<?php echo e($og->thumbnail); ?>

                                      " sizes="(max-width: 300px) 100vw, 300px" /></noscript><img style="width:300px; height:300px;" src="/storage/<?php echo e($og->thumbnail); ?>" data-src="" class="lazyload attachment-woocommerce_thumbnail size-woocommerce_thumbnail"  data-sizes="(max-width: 300px) 100vw, 300px" />
                                                    </a>
                                                </div>
                                                <div class="image-tools is-small top right show-on-hover"></div>
                                                <div class="image-tools is-small hide-for-small bottom left show-on-hover">
                                                </div>
                                                <div class="image-tools grid-tools text-center hide-for-small bottom hover-slide-in show-on-hover">
                                                </div>
                                            </div>
                                            <div class="box-text box-text-products text-center grid-style-2">
                                                <div class="title-wrapper">
                                                    <p class="name product-title woocommerce-loop-product__title">
                                                        <a href="chi-tiet-san-pham/<?php echo e($og->slug); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><?php echo e($og->title); ?></a>
                                                    </p>
                                                </div>
                                                <div class="price-wrapper">
                                                    <span class="price">
                                                        <ins><span class="woocommerce-Price-amount amount"><bdi><?php echo e($og->price); ?><span class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span></ins></span>
                                                </div>
                                                <div class="add-to-cart-button">
                                                    <!-- <a href="indexb028.html?add-to-cart=1789" data-quantity="1" class="primary is-small mb-0 button product_type_simple add_to_cart_button ajax_add_to_cart is-flat" data-product_id="1789" data-product_sku aria-label="Thêm &ldquo;Ốc Bươu Đen Giống 5 Tuần Tuổi&rdquo; vào giỏ hàng" rel="nofollow">Mua hàng</a> -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div id="col-1984410756" class="col show-for-small medium-9 small-12 large-9">
                        <div class="col-inner">
                            <div class="row large-columns-3 medium-columns- small-columns-2 row-normal slider row-slider slider-nav-reveal slider-nav-push" data-flickity-options='{"imagesLoaded": true, "groupCells": "100%", "dragThreshold" : 5, "cellAlign": "left","wrapAround": true,"prevNextButtons": true,"percentPosition": true,"pageDots": false, "rightToLeft": false, "autoPlay" : 4000}'>
                                <?php $__currentLoopData = $ocgiong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $og): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product-small col has-hover product type-product post-1789 status-publish instock product_cat-oc-giong has-post-thumbnail sale shipping-taxable purchasable product-type-simple">
                                    <div class="col-inner">
                                        <div class="badge-container absolute left top z-1">
                                            <div class="callout badge badge-square">
                                                <!-- <div class="badge-inner secondary on-sale">
                                                    <span class="onsale">-8%</span>
                                                </div> -->
                                            </div>
                                        </div>
                                        <div class="product-small box">
                                            <div class="box-image">
                                                <div class="image-none">
                                                    <a href="chi-tiet-san-pham/<?php echo e($og->slug); ?>">
                                                        <noscript><img style="width:300px; height:300px;" src="/storage/<?php echo e($og->thumbnail); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt srcset="
                                                        /storage/<?php echo e($og->thumbnail); ?>

                                      " sizes="(max-width: 300px) 100vw, 300px" /></noscript><img style="width:300px; height:300px;" src="/storage/<?php echo e($og->thumbnail); ?>" data-src="" class="lazyload attachment-woocommerce_thumbnail size-woocommerce_thumbnail"  data-sizes="(max-width: 300px) 100vw, 300px" />
                                                    </a>
                                                </div>
                                                <div class="image-tools is-small top right show-on-hover"></div>
                                                <div class="image-tools is-small hide-for-small bottom left show-on-hover">
                                                </div>
                                                <div class="image-tools grid-tools text-center hide-for-small bottom hover-slide-in show-on-hover">
                                                </div>
                                            </div>
                                            <div class="box-text box-text-products text-center grid-style-2">
                                                <div class="title-wrapper">
                                                    <p class="name product-title woocommerce-loop-product__title">
                                                        <a href="chi-tiet-san-pham/<?php echo e($og->slug); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><?php echo e($og->title); ?></a>
                                                    </p>
                                                </div>
                                                <div class="price-wrapper">
                                                    <span class="price">
                                                        <ins><span class="woocommerce-Price-amount amount"><bdi><?php echo e($og->price); ?><span class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span></ins></span>
                                                </div>
                                                <div class="add-to-cart-button">
                                                    <!-- <a href="indexb028.html?add-to-cart=1789" data-quantity="1" class="primary is-small mb-0 button product_type_simple add_to_cart_button ajax_add_to_cart is-flat" data-product_id="1789" data-product_sku aria-label="Thêm &ldquo;Ốc Bươu Đen Giống 5 Tuần Tuổi&rdquo; vào giỏ hàng" rel="nofollow">Mua hàng</a> -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div id="col-144760019" class="col hide-for-small medium-3 small-12 large-3">
                        <div class="col-inner">
                            <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1941700314">
                                <div class="img-inner image-cover dark" style="padding-top: 195%">
                                    <noscript><img style="width:445px; height:829px;" src="../images/hinh-4.jpg" class="attachment-original size-original" alt srcset="
                                    ../images/hinh-4.jpg
                            " sizes="(max-width: 445px) 100vw, 445px" /></noscript><img style="width:445px; height:829px;" src="../images/hinh-4.jpg" data-src="../images/hinh-4.jpg" class="lazyload attachment-original size-original" data-sizes="(max-width: 445px) 100vw, 445px" />
                                </div>
                                <style>
                                    #image_1941700314 {
                                        width: 100%;
                                    }
                                </style>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <style>
                #section_1854132819 {
                    padding-top: 30px;
                    padding-bottom: 30px;
                }
            </style>
        </section>
        
        
        <section class="section section-tin-tuc" id="section_617855382">
            <div class="bg section-bg fill bg-fill bg-loaded"></div>
            <div class="section-content relative">
                <div class="row row-small" id="row-951489784">
                    <div id="col-551682880" class="col small-12 large-12">
                        <div class="col-inner">
                            <h3 class="tieu-de">
                                <b></b>TIN TỨC &#8211; BÀI VIẾT<b></b>
                            </h3>
                            <div id="gap-454782490" class="gap-element clearfix" style="display: block; height: auto">
                                <style>
                                    #gap-454782490 {
                                        padding-top: 20px;
                                    }
                                </style>
                            </div>
                            <div class="row large-columns-3 medium-columns-2 small-columns-1 slider row-slider slider-nav-reveal slider-nav-push" data-flickity-options='{"imagesLoaded": true, "groupCells": "100%", "dragThreshold" : 5, "cellAlign": "left","wrapAround": true,"prevNextButtons": true,"percentPosition": true,"pageDots": false, "rightToLeft": false, "autoPlay" : false}'>
                            <?php $__currentLoopData = $tintuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <div class="col post-item">
                                    <div class="col-inner">
                                        <a href="/chi-tiet-tin-tuc/<?php echo e($tt->slug); ?>" class="plain">
                                            <div class="box box-normal box-text-bottom box-blog-post has-hover">
                                                <div class="box-image">
                                                    <div class="image-zoom image-cover" style="padding-top: 71%">
                                                        <noscript><img style="width:2560px; height:1920px;" src="/storage/<?php echo e($tt->thumbnail); ?>" class="attachment-original size-original wp-post-image" alt="<?php echo e($tt->title); ?>" srcset="
                                       
                                      " sizes="(max-width: 2560px) 100vw, 2560px" /></noscript><img style="width:2560px; height:1920px;" src="/storage/<?php echo e($tt->thumbnail); ?>"  data-sizes="(max-width: 2560px) 100vw, 2560px" />
                                                    </div>
                                                </div>
                                                <div class="box-text text-center">
                                                    <div class="box-text-inner blog-post-inner">
                                                        <h5 class="post-title is-large uppercase">
                                                            <?php echo e($tt->title); ?>

                                                        </h5>
                                                        <div class="is-divider"></div>
                                                        <p class="from_the_blog_excerpt">
                                                            <?php echo e($tt->excerpt); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <style>
                #section_617855382 {
                    padding-top: 30px;
                    padding-bottom: 30px;
                }
            </style>
        </section>
        <div class="row row-small" id="row-157740713">
            <div id="col-599542509" class="col hide-for-small medium-3 small-6 large-3">
                <div class="col-inner">
                    <div class="icon-box featured-box icon-box-left text-left">
                        <div class="icon-box-img" style="width: 54px">
                            <div class="icon">
                                <div class="icon-inner">
                                    <noscript><img width="66" height="66" src="../images/icon1.jpg" class="attachment-medium size-medium" alt /></noscript><img width="66" height="66" src="../images/icon1.jpg" data-src="https://traiocgiong.com/../images/icon1.jpg" class="lazyload attachment-medium size-medium" alt />
                                </div>
                            </div>
                        </div>
                        <div class="icon-box-text last-reset">
                            <p>
                                <span style="font-size: 120%"><strong><span style="color: #008000">Vận chuyển
                                            miễn
                                            phí</span></strong></span><br />
                                với đơn hàng &gt;2.000.000đ
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div id="col-798787680" class="col hide-for-small medium-3 small-6 large-3">
                <div class="col-inner">
                    <div class="icon-box featured-box icon-box-left text-left">
                        <div class="icon-box-img" style="width: 54px">
                            <div class="icon">
                                <div class="icon-inner">
                                    <noscript><img width="66" height="66" src="../images/icon2.jpg" class="attachment-medium size-medium" alt /></noscript><img width="66" height="66" src="../images/icon2.jpg" data-src="https://traiocgiong.com/../images/icon2.jpg" class="lazyload attachment-medium size-medium" alt />
                                </div>
                            </div>
                        </div>
                        <div class="icon-box-text last-reset">
                            <p>
                                <span style="font-size: 120%"><strong><span style="color: #008000">Chất lượng
                                            bảo
                                            đảm</span></strong></span><br />
                                100% giống ốc bươu đen
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div id="col-1374006858" class="col hide-for-small medium-3 small-6 large-3">
                <div class="col-inner">
                    <div class="icon-box featured-box icon-box-left text-left">
                        <div class="icon-box-img" style="width: 54px">
                            <div class="icon">
                                <div class="icon-inner">
                                    <noscript><img width="66" height="66" src="../images/icon3.jpg" class="attachment-medium size-medium" alt /></noscript><img width="66" height="66" src="../images/icon3.jpg" data-src="https://traiocgiong.com/../images/icon3.jpg" class="lazyload attachment-medium size-medium" alt />
                                </div>
                            </div>
                        </div>
                        <div class="icon-box-text last-reset">
                            <p>
                                <span style="color: #008000"><span style="font-size: 17.28px; line-height: 25.92px"><b>Dịch
                                            vụ đẳng cấp<br /> </b></span></span>Dịch
                                vụ 5 sao,
                                hậu mãi chuyên nghiệp
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div id="col-27833174" class="col hide-for-small medium-3 small-6 large-3">
                <div class="col-inner">
                    <div class="icon-box featured-box icon-box-left text-left">
                        <div class="icon-box-img" style="width: 54px">
                            <div class="icon">
                                <div class="icon-inner">
                                    <noscript><img width="66" height="66" src="../images/icon4.jpg" class="attachment-medium size-medium" alt /></noscript><img width="66" height="66" src="../images/icon4.jpg" data-src="https://traiocgiong.com/../images/icon4.jpg" class="lazyload attachment-medium size-medium" alt />
                                </div>
                            </div>
                        </div>
                        <div class="icon-box-text last-reset">
                            <p>
                                <span style="color: #008000"><span style="font-size: 17.28px; line-height: 25.92px"><b>Hỗ
                                            trợ miễn phí<br /> </b></span></span>Từ:
                                08h00
                                &#8211; 23h00
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row" id="row-1826770595">
            <div id="col-473232913" class="col show-for-small small-12 large-12">
                <div class="col-inner">
                    <div class="icon-box featured-box icon-box-left text-left">
                        <div class="icon-box-img" style="width: 50px">
                            <div class="icon">
                                <div class="icon-inner">
                                    <noscript><img width="66" height="66" src="../images/icon1.jpg" class="attachment-medium size-medium" alt /></noscript><img width="66" height="66" src="../images/icon1.jpg" data-src="https://traiocgiong.com/../images/icon1.jpg" class="lazyload attachment-medium size-medium" alt />
                                </div>
                            </div>
                        </div>
                        <div class="icon-box-text last-reset">
                            <p>
                                <span style="font-size: 120%"><strong><span style="color: #008000">Vận chuyển
                                            miễn
                                            phí</span></strong></span><br />
                                với đơn hàng &gt;600.000đ
                            </p>
                        </div>
                    </div>
                    <div id="gap-1816577885" class="gap-element clearfix" style="display: block; height: auto">
                        <style>
                            #gap-1816577885 {
                                padding-top: 19px;
                            }
                        </style>
                    </div>
                    <div class="icon-box featured-box icon-box-left text-left">
                        <div class="icon-box-img" style="width: 50px">
                            <div class="icon">
                                <div class="icon-inner">
                                    <noscript><img width="66" height="66" src="../images/icon2.jpg" class="attachment-medium size-medium" alt /></noscript><img width="66" height="66" src="../images/icon1.jpg" data-src="https://traiocgiong.com/../images/icon2.jpg" class="lazyload attachment-medium size-medium" alt />
                                </div>
                            </div>
                        </div>
                        <div class="icon-box-text last-reset">
                            <p>
                                <span style="font-size: 120%"><strong><span style="color: #008000">Chất lượng
                                            bảo
                                            đảm</span></strong></span><br />
                                hàng chính hãng
                            </p>
                        </div>
                    </div>
                    <div id="gap-171082429" class="gap-element clearfix" style="display: block; height: auto">
                        <style>
                            #gap-171082429 {
                                padding-top: 19px;
                            }
                        </style>
                    </div>
                    <div class="icon-box featured-box icon-box-left text-left">
                        <div class="icon-box-img" style="width: 50px">
                            <div class="icon">
                                <div class="icon-inner">
                                    <noscript><img width="66" height="66" src="../images/icon3.jpg" class="attachment-medium size-medium" alt /></noscript><img width="66" height="66" src="../images/icon1.jpg" data-src="https://traiocgiong.com/../images/icon3.jpg" class="lazyload attachment-medium size-medium" alt />
                                </div>
                            </div>
                        </div>
                        <div class="icon-box-text last-reset">
                            <p>
                                <span style="color: #008000"><span style="font-size: 17.28px; line-height: 25.92px"><b>Đổi
                                            trả miễn phí<br /> </b></span></span>trong
                                vòng 15
                                ngày
                            </p>
                        </div>
                    </div>
                    <div id="gap-156470214" class="gap-element clearfix" style="display: block; height: auto">
                        <style>
                            #gap-156470214 {
                                padding-top: 19px;
                            }
                        </style>
                    </div>
                    <div class="icon-box featured-box icon-box-left text-left">
                        <div class="icon-box-img" style="width: 50px">
                            <div class="icon">
                                <div class="icon-inner">
                                    <noscript><img width="66" height="66" src="../images/icon4.jpg" class="attachment-medium size-medium" alt /></noscript><img width="66" height="66" src="../images/icon1.jpg" data-src="https://traiocgiong.com/../images/icon4.jpg" class="lazyload attachment-medium size-medium" alt />
                                </div>
                            </div>
                        </div>
                        <div class="icon-box-text last-reset">
                            <p>
                                <span style="color: #008000"><span style="font-size: 17.28px; line-height: 25.92px"><b>Hỗ
                                            trợ miễn phí<br /> </b></span></span>Từ:
                                06h30
                                &#8211; 23h00
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ocbuouden.views.layouts.trangchu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\web_ocoop\resources\views/ocbuouden/posts/home.blade.php ENDPATH**/ ?>