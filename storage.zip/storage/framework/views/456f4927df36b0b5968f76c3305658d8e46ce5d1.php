
<?php $__env->startSection('content'); ?>

<main id="main" class="">
    <div class="page-wrapper page-left-sidebar">
        <div class="row">
            <div id="content" class="large-12 right col" role="main">
                <div class="page-inner">
                    <section class="section" id="section_1195375054">
                        <div class="bg section-bg fill bg-fill  bg-loaded"></div>
                        <div class="section-content relative">
                            <div class="row" id="row-1201448317">
                                <script data-rocketlazyloadscript='https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6941773220112151' async crossorigin="anonymous"></script>
                                </p>
                                <div id="col-513812917" class="col medium-12 small-12 large-12">
                                    <div class="col-inner">
                                        <h2>Liên hệ với chúng tôi</h2>
                                        
                                    </div>
                                </div>
                                <iframe style="border: 0;" tabindex="0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31415.692377971965!2d106.51565073955078!3d10.1837782!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3173c79b9b8928b9%3A0xa042c4e36d39a3d9!2zVHLhuqFpIOG7kWMgYsawxqF1IGdp4buRbmcgLSB0cuG7qW5nIOG7kWMgYsawxqF1IMSRZW4gLSDhu5FjIGLGsMahdSDEkWVuIHRoxrDGoW5nIHBo4bqpbQ!5e0!3m2!1svi!2sus!4v1606199490534!5m2!1svi!2sus" width="100%" height="450" frameborder="0" allowfullscreen="allowfullscreen" aria-hidden="false"></iframe><br />
                        </div>
                        <style>
                            #section_1195375054 {
                                padding-top: 30px;
                                padding-bottom: 30px;
                            }
                        </style>
                    </section>
                    
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ocbuouden.views.layouts.trangchu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\web_ocoop\resources\views/ocbuouden/posts/lienhe.blade.php ENDPATH**/ ?>