
<?php $__env->startSection('content'); ?>
<div class="swap-content w-clear" style="margin-top: 30px">
    <div class="content" style="padding-bottom: 0;">
        <div class="title_main_in"><span>SẢN PHẨM</span></div>
        <div class="w-clear center news_chil">
            <?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="item item-home">
                    <div class="images">

                        

                        <a href="/chi-tiet-san-pham/<?php echo e($sp->slug); ?>" title="<?php echo e($sp->title); ?> ">

                            <img src="/storage/<?php echo e($sp->thumbnail); ?>" alt="<?php echo e($sp->title); ?> " class="img-responsive" style="height: 308px; width: 358px" />
                 
                        </a>
                    </div>
                    <div class="product-name text-uppercase">
                        <a href="/chi-tiet-san-pham/<?php echo e($sp->slug); ?>" title="<?php echo e($sp->title); ?>"><?php echo e($sp->title); ?> </a>
                        <div class="giakm">
                        <?php echo e($sp->price); ?> <span>VNĐ</span>
                        </div>
                    </div>
                    <div class="product-detail text-center">
                        <a href="/chi-tiet-san-pham/<?php echo e($sp->slug); ?>" title="<?php echo e($sp->slug); ?> ">
                            <img src="../images/icon-book.png" alt="Chi Tiết"> Chi Tiết
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </div><!--end w-clear-->


        <div style="width:200px; margin:auto"> <?php echo e($sanpham->links()); ?></div>
       

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('thucphamquangtrang.views.layouts.trangchu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\web_ocoop\resources\views/thucphamquangtrang/posts/sanpham.blade.php ENDPATH**/ ?>