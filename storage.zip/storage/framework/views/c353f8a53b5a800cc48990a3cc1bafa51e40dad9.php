
<?php $__env->startSection('content'); ?>
<?php if($chitietvideo): ?>
<div class="swap-content w-clear" style="margin-top: 30px">
    <div id="main_content_web">
        <div class="block_content w-clear center news_chil">
            <ul class="breadcrumb">
                <li><a href="/" class="transitionAll">Trang chủ</a> </li>
                <li><a href="" class="transitionAll">Video</a> </li>
            </ul>
            <div class="title_main_in"><span><?php echo e($chitietvideo->title); ?></span></div>
            <div class="clear"></div>
            <div class="show-pro">
                <div id="box_video">
                    <iframe width="100%" height="470" src="<?php echo e($chitietvideo->youtube_id); ?>" frameborder="0" allowfullscreen></iframe>
                </div>
                <!-- <div class="title-detail">Mô tả sản phẩm</div> -->
                <div class="clear"></div>
                <div style="margin:20px 0">
                    <!-- AddThis Button BEGIN -->
                    <div class="addthis_toolbox addthis_default_style">
                        <a class="addthis_button_facebook_like" fb:like:layout="button_count"></a>
                        <a class="addthis_button_tweet"></a>
                        <a class="addthis_button_google_plusone" g:plusone:size="medium"></a>
                        <a class="addthis_counter addthis_pill_style"></a>
                    </div>
                    <script type="text/javascript">
                        var addthis_config = {
                            "data_track_addressbar": false
                        };
                    </script>
                    <script type="text/javascript" src="../../s7.addthis.com/js/300/addthis_widget.js#pubid=ra-52843d4e1ff0313a"></script>
                </div>
                <div class="chitiettin"></div>
            </div>
            <div class="title_main_in"><span>Video cùng loại</span></div>
            <div class="video-content">
                <div class="row">
                    <?php $__currentLoopData = $videolienquan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vdlq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-video col-sm-4">
                        <a href="/chi-tiet-video/<?php echo e($vdlq->slug); ?>">
                            <div class="image">
                                <img src="/storage/<?php echo e($vdlq->thumbnail); ?>" alt="<?php echo e($vdlq->title); ?> ">
                            </div>
                            <div class="video-name"><?php echo e($vdlq->title); ?> </div>
                            <span class="hover-video"></span>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('thucphamquangtrang.views.layouts.trangchu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\web_ocoop\resources\views/thucphamquangtrang/posts/chitietvideo.blade.php ENDPATH**/ ?>