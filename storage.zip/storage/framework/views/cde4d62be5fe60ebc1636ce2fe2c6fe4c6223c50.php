
<?php $__env->startSection('content'); ?>

<div id="content" role="main">
    <div class="page-header dark larger larger-desc">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ol class="breadcrumb title-wrapper">

                        <li><a href="/"><i class="fa fa-home"></i> Trang chủ</a></li>
                        <li><a href="/san-pham">Sản phẩm</a></li>
                        <li></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-9 col-md-push-3">
                <div class="mt10"></div>
                <div class="filter-row clearfix">
                    <form action="http://qnafarm.com/san-pham.html?search=&amp;order=1&amp;showpage=12">

                    </form>
                </div>

                <div class="row">

                    <div class="col large-12">
                        <div class="shop-container danh-muc-section">
                            <div class="woocommerce-notices-wrapper"></div>
                            <div class="row equalize-box large-columns-4 medium-columns-3 small-columns-2 row-xsmall">
                            <?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col">
                                    <div class="col-inner">

                                        <div class="product-small box has-hover box-normal box-text-bottom">
                                            <div class="box-image">
                                                <div class="image-zoom image-cover" style="padding-top:100%;">
                                                    <a href="/chi-tiet-san-pham/<?php echo e($sp->slug); ?>" alt="<?php echo e($sp->title); ?>">
                                                        <img style="width:300px; height:300px;" width="300" height="300" src="/storage/<?php echo e($sp->thumbnail); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="<?php echo e($sp->title); ?>" srcset="/storage/<?php echo e($sp->thumbnail); ?> 300w, /storage/<?php echo e($sp->thumbnail); ?> 150w, /storage/<?php echo e($sp->thumbnail); ?> 100w" sizes="(max-width: 300px) 100vw, 300px" />
                                                    </a>
                                                </div>
                                                <div class="image-tools top right show-on-hover"></div>
                                                <div class="image-tools grid-tools text-center hide-for-small bottom hover-slide-in show-on-hover">
                                                </div>
                                            </div>
                                            <!-- box-image -->

                                            <div class="box-text text-left">
                                                <div class="title-wrapper">
                                                    <p class="name product-title name_product_gird"><a href="/chi-tiet-san-pham/<?php echo e($sp->slug); ?>"><?php echo e($sp->title); ?></a>
                                                    </p>
                                                </div>
                                                <div class="price-wrapper">
                                                    <span class="price">
                                                        <ins><span class="amount"><?php echo e($sp->price); ?>đ</span></ins>

                                                    </span>
                                                </div>

                                            </div>
                                            <!-- box-text -->
                                        </div>
                                        <!-- box -->
                                    </div>
                                    <!-- .col-inner -->
                                </div>
                                <!-- col -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <!-- row -->
                        </div>
                        <!-- shop container -->
                    </div>
                    <!-- .large-12  -->
                </div>


                <nav class="text-center">
                    <nav class="pagination-container">
                        <ul class="pagination">
                            <li class="page-item active"><?php echo e($sanpham->links()); ?></li>
                        </ul>
                    </nav>
                </nav>


                <script type="text/javascript">
                    $('#change_order').on('change', function() {
                        this.form.submit();
                    });
                    $('#change_price').on('change', function() {
                        this.form.submit();
                    });
                </script>

            </div>

            <div class="mb30 visible-sm visible-xs"></div><!-- space -->

            <aside class="col-md-3 col-md-pull-9 sidebar">
                <div class="widget">
                    <h3 class="title_widget">Tin mới nhất</h3>


                    <?php $__currentLoopData = $tinmoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-article clearfix">
                        <div class="post-image">
                            <a href="/chi-tiet-tin-tuc/<?php echo e($tm->slug); ?>"><img src="/storage/<?php echo e($tm->thumbnail); ?>" alt="<?php echo e($tm->title); ?>">
                            </a>
                        </div>

                        <div class="post-content" style="width: 163px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    text-align: justify;">
                            <h3>
                                <a href="/chi-tiet-tin-tuc/<?php echo e($tm->slug); ?>"><?php echo $tm->excerpt; ?></a>
                            </h3>
                            <span class="author">
                                <div class="post-meta is-small op-8"><?php echo e($tm->created_at->format('d/m/Y')); ?> - by <a href="#">admin</a></div>
                                <div class="is-divider"></div>
                            </span>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </aside>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.trangchu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\web_ocoop\resources\views/posts/sanpham.blade.php ENDPATH**/ ?>